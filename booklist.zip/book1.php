<?php 
if(isset($_POST['submit'])){
	$name= $_POST['name'];
	$pname=$_POST['pname'];
	$pbage= $_POST['pbage'];

	$pno= $_POST['pno'];
	$publishdate=$_POST['publishdate'];

	$host='localhost';
	$user='root';
	$pass='';
	$dbname= 'booklist1';


	$conn= mysqli_connect($host,$user,$pass,$dbname);

	$sql= " INSERT INTO veiwbook(name,pname,pbage,pno,publishdate) value('$name','$pname','$pbage','$pno','$publishdate')";

	mysqli_query($conn,$sql);                    

};

?>

<!DOCTYPE html>
<html>
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>book management</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>

	
	<div class="form">
		<h1>Book management</h1>
	<form action="#" method="POST">
		 Name:<input type="text" name="name"> <br>
		publisher name:<input type="text" name="pname"><br>
		publisher age:<input type="number" name="pbage"><br>
		page no: <input type="number" name="pno"><br>
		publish date: <input type="text" name="publishdate"><br>
		
           <h3 >type</h3>
		<INPUT TYPE="Checkbox" Name="type" Value ="sci-fi">sci-fi
        <INPUT TYPE="Checkbox" Name= "type" Value ="drama ">drama
          <INPUT TYPE="Checkbox" Name= "type" Value ="nobel">nobel
          <br>

          <input type="submit" name="submit" value=" send data">
	</form>
</div>

   

</body>